package com.tawasul.app.authentication

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.tawasul.app.BuildConfig
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoogleCredentialHelper @Inject constructor() {

    sealed class CredentialResult {
        data class Success(val idToken: String) : CredentialResult()
        data object Cancelled : CredentialResult()
        data class Error(val messageAr: String) : CredentialResult()
    }

    suspend fun requestGoogleIdToken(activityContext: Context): CredentialResult {
        val webClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (webClientId.isBlank() || webClientId.startsWith("REPLACE_WITH")) {
            return CredentialResult.Error(
                "لم يتم ضبط GOOGLE_WEB_CLIENT_ID في local.properties أو Firebase بعد."
            )
        }

        val credentialManager = CredentialManager.create(activityContext)
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId)
            .setAutoSelectEnabled(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        return try {
            val result = credentialManager.getCredential(
                context = activityContext,
                request = request
            )
            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdCredential = GoogleIdTokenCredential.createFrom(credential.data)
                CredentialResult.Success(googleIdCredential.idToken)
            } else {
                CredentialResult.Error("نوع بيانات الاعتماد غير مدعوم.")
            }
        } catch (_: GetCredentialCancellationException) {
            CredentialResult.Cancelled
        } catch (_: NoCredentialException) {
            CredentialResult.Error("لا يوجد حساب Google متاح على هذا الجهاز لتسجيل الدخول.")
        } catch (e: Exception) {
            CredentialResult.Error(e.localizedMessage ?: "تعذر تسجيل الدخول عبر Google.")
        }
    }
}
